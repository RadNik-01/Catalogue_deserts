from .models import *
from django import forms

class DesertForm(forms.ModelForm):
    class Meta:
        model = Desert
        fields = ['category', 'cake_id', 'image', 'name', 'diameter', 'height', 'weight', 'about_text', 'price']

