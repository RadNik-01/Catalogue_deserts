from. import views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.mainpage_open, name='home'),
    path('resume', views.resume_open),
    path('content', views.content_open, name='content'),
    path('content/<int:pk>', views.DesertFullInfo.as_view(), name='desert'),
    path('create', views.create, name='create')
]
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
