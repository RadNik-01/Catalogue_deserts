from django.db import models
class Desert (models.Model):
    category = models.CharField('Категория', max_length=30)
    cake_id = models.SlugField('ID продукта', max_length=200, db_index=True)
    image = models.FileField(null=True, blank=True)
    name = models.CharField('Название', max_length=30)
    diameter = models.IntegerField('Диаметр(мм)')
    height = models.IntegerField('Высота(мм)')
    weight = models.IntegerField('Вес(грамм)')
    about_text = models.TextField('описание', max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name

