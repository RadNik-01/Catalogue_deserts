from django.shortcuts import render, redirect
from .models import Desert
from django.views.generic import DetailView
from .forms import DesertForm


def mainpage_open(request):
    return render(request, 'mainpage/index.html')
def resume_open(request):
    return render(request, 'mainpage/resume.html')
def content_open(request):
    deserts = Desert.objects.all()
    return render(request, 'mainpage/content.html', {'deserts': deserts})

class DesertFullInfo(DetailView):
    model = Desert
    template_name = 'mainpage/desert.html'
    context_object_name = 'desert'

def create(request):
    form = DesertForm
    if request.method == "POST":
        form = DesertForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.save()
            return redirect('content')
    else:
        form = DesertForm()
    return render(request, 'mainpage/desertpost.html', locals())
