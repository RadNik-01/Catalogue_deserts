from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Desert',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('category', models.CharField(max_length=30, verbose_name='Категория')),
                ('cake_id', models.SlugField(max_length=200, verbose_name='ID продукта')),
                ('image', models.FileField(blank=True, null=True, upload_to='')),
                ('name', models.CharField(max_length=30, verbose_name='Название')),
                ('diameter', models.IntegerField(verbose_name='Диаметр(мм)')),
                ('height', models.IntegerField(verbose_name='Высота(мм)')),
                ('weight', models.IntegerField(verbose_name='Вес(кг)')),
                ('about_text', models.TextField(max_length=200, verbose_name='описание')),
                ('price', models.DecimalField(decimal_places=2, max_digits=10)),
            ],
        ),
    ]
